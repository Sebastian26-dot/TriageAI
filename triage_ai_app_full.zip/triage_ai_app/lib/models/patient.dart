class Patient {
  final String id;
  final String name;
  final int age;
  final String symptoms;
  final String condition;
  final int severityScore;

  Patient({
    required this.id,
    required this.name,
    required this.age,
    required this.symptoms,
    required this.condition,
    required this.severityScore,
  });

  factory Patient.fromJson(Map<String, dynamic> json) {
    return Patient(
      id: json['id'],
      name: json['name'],
      age: json['age'],
      symptoms: json['symptoms'],
      condition: json['condition'],
      severityScore: json['severity_score'],
    );
  }
}
