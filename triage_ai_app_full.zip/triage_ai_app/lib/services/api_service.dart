import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/patient.dart';

class ApiService {
  static const String baseUrl = 'https://your-backend-url.up.railway.app'; // Ganti URL ini

  Future<List<Patient>> fetchPatients() async {
    final response = await http.get(Uri.parse('$baseUrl/patients'));
    if (response.statusCode == 200) {
      List data = json.decode(response.body);
      return data.map((patient) => Patient.fromJson(patient)).toList();
    } else {
      throw Exception('Failed to load patients');
    }
  }

  Future<void> addPatient(String name, int age, String symptoms) async {
    final response = await http.post(
      Uri.parse('$baseUrl/add_patient'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'name': name,
        'age': age,
        'symptoms': symptoms,
      }),
    );
    if (response.statusCode != 200) {
      throw Exception('Failed to add patient');
    }
  }
}
